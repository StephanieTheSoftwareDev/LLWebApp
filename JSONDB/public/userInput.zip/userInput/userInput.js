$(document).ready(function () {

    var uiSubmitBtn = document.getElementById('uiSubmitBtn');


    
    uiSubmitBtn.addEventListener('click', function () {
        var $nodeName = $("input[name='nodeName']").val(); 
        var $nodeType = $("input[name='nodeType']").val();
        var $nodeText = $("input[name='nodeText']").val();
        var $nodeDetails = $("input[name='nodeDetails']").val();
        var $nextNodeChoice1 = $("input[name='choice1']").val();
        var $nextNodeChoice2 = $("input[name='choice2']").val();
        var $nextNodeChoice3 = $("input[name='choice3']").val();
        
        var contentPage = JSON.stringify({
            'nodeName': $nodeName,
            'nodeType': $nodeType,
            'nodeText': $nodeText,
            'nodeDetails': $nodeDetails,
            'nextNodes': [
                {
                'choice1': $nextNodeChoice1,
                'id': ''
                },
                {
                'choice2': $nextNodeChoice2,
                'id': ''
                },
                {
                'choice3': $nextNodeChoice3,
                'id': ''
                }
            ]
        })
        

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'http://localhost:3000/pages',
            data: contentPage,
            contentType: 'application/json; charset=utf-8',
            
        })
    });





});